export type Note = {
  note_id: string;
  note_title: string;
  note_content: string;
  created_on: string;  
  last_update: string;
};